/** Router-admin reality vs what this LAN scanner measures — no fake data. */
function capT(k) {
  return typeof window.t === 'function' ? window.t(k) : k;
}

function escCap(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function statusBadge(status) {
  if (status === 'supported') return `<span class="cap-badge cap-yes">${capT('cap.yes')}</span>`;
  if (status === 'partial') return `<span class="cap-badge cap-part">${capT('cap.part')}</span>`;
  return `<span class="cap-badge cap-no">${capT('cap.no')}</span>`;
}

function renderSectionTable(items) {
  if (!items?.length) return '';
  const rows = items
    .map(
      (c) =>
        `<tr>
          <th>${escCap(c.label)}</th>
          <td>${statusBadge(c.status)}</td>
          <td>${c.we_provide ? escCap(c.we_provide) : '<span class="muted">—</span>'}</td>
          <td>${escCap(c.router_typical || '—')}</td>
        </tr>`,
    )
    .join('');
  return (
    '<table class="cap-table">' +
    `<thead><tr><th>${capT('cap.th.type')}</th><th></th><th>${capT('cap.th.app')}</th><th>${capT('cap.th.router')}</th></tr></thead>` +
    '<tbody>' + rows + '</tbody></table>'
  );
}

function renderContextBlock(data) {
  const depends = (data.depends_on || [])
    .map((d) => `<li>${escCap(d)}</li>`)
    .join('');
  const https = (data.https_cannot_see || [])
    .map((d) => `<li>${escCap(d)}</li>`)
    .join('');
  const s = data.summary || {};
  return (
    '<div class="cap-context">' +
    '<p class="cap-intro">' +
    escCap(data.this_app_role || '') +
    ` <strong>${capT('cap.noFake')}</strong> ${capT('cap.th.app')}: ` +
    `${escCap(s.supported)} full, ${escCap(s.partial)} partial, ${escCap(s.unavailable)} not collected here.` +
    '</p>' +
    `<h3 class="cap-h3">${capT('cap.depends')}</h3>` +
    '<ul class="cap-list">' + depends + '</ul>' +
    `<h3 class="cap-h3">${capT('cap.https')}</h3>` +
    '<ul class="cap-list cap-list-warn">' + https + '</ul>' +
    '</div>'
  );
}

function renderSections(sections) {
  if (!sections?.length) return renderSectionTable([]);
  return sections
    .map(
      (sec) =>
        '<div class="cap-section">' +
        `<h3 class="cap-h3">${escCap(sec.title)}</h3>` +
        `<p class="sub cap-section-intro">${escCap(sec.intro || '')}</p>` +
        renderSectionTable(sec.items) +
        '</div>',
    )
    .join('');
}

async function fetchCapabilities() {
  try {
    const res = await fetch('/api/capabilities');
    if (res.ok) return await res.json();
  } catch (_) {}
  return null;
}

window.renderCapabilitiesInto = async function (elementId) {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.innerHTML = `<p class="sub">${capT('map.cap.loading')}</p>`;
  const data = await fetchCapabilities();
  if (!data?.items) {
    el.innerHTML = `<p class="sub">${capT('cap.loadGuide')}</p>`;
    return;
  }
  el.innerHTML = renderContextBlock(data) + renderSections(data.sections);
};
