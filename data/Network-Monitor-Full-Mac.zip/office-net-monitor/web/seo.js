/** Inject meta tags, Open Graph, Twitter Card, canonical URL, JSON-LD. */
(function () {
  const cfg = window.SEO_CONFIG;
  if (!cfg) return;

  const pageKey =
    document.documentElement.getAttribute('data-seo-page') ||
    (location.pathname.includes('devices') ? 'devices' : location.pathname.includes('map') ? 'map' : location.pathname.includes('about') ? 'about' : 'home');
  const page = cfg.pages[pageKey] || cfg.pages.home;
  const origin = cfg.siteOrigin.replace(/\/$/, '');
  const canonical = origin + page.path.replace(/\/$/, page.path === '/' ? '/' : page.path);
  const title = page.title;
  const description = page.description;
  const image = cfg.defaultImage;
  const keywords = (cfg.keywords || []).join(', ');

  function setMeta(name, content, prop) {
    if (!content) return;
    const attr = prop ? 'property' : 'name';
    const sel = prop ? `meta[property="${name}"]` : `meta[name="${name}"]`;
    let el = document.querySelector(sel);
    if (!el) {
      el = document.createElement('meta');
      el.setAttribute(attr, name);
      document.head.appendChild(el);
    }
    el.setAttribute('content', content);
  }

  function setLink(rel, href, extra) {
    if (!href) return;
    let el = document.querySelector(`link[rel="${rel}"]`);
    if (!el) {
      el = document.createElement('link');
      el.rel = rel;
      document.head.appendChild(el);
    }
    el.href = href;
    if (extra) Object.keys(extra).forEach((k) => el.setAttribute(k, extra[k]));
  }

  document.title = title;
  setMeta('description', description);
  setMeta('keywords', keywords);
  setMeta('author', cfg.creator);
  setMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1');
  setMeta('google-site-verification', cfg.googleVerification);
  setMeta('application-name', cfg.siteName);

  setMeta('og:type', 'website', true);
  setMeta('og:site_name', cfg.siteName + ' · ' + cfg.brand, true);
  setMeta('og:title', title, true);
  setMeta('og:description', description, true);
  setMeta('og:url', canonical, true);
  setMeta('og:image', image, true);
  setMeta('og:locale', 'en_US', true);

  setMeta('twitter:card', 'summary_large_image');
  setMeta('twitter:title', title);
  setMeta('twitter:description', description);
  setMeta('twitter:image', image);

  setLink('canonical', canonical);
  setLink('alternate', canonical, { hreflang: 'en' });
  setLink('alternate', canonical, { hreflang: 'x-default' });
  setLink('me', cfg.linkedIn);
  setLink('me', cfg.instagram);

  const graph = [
    {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      '@id': origin + '/#website',
      url: origin + '/',
      name: cfg.siteName,
      alternateName: [cfg.brand, 'network.linux-aios.com', 'Linux AIOS Network Monitor'],
      description: description,
      publisher: { '@id': origin + '/#person' },
      inLanguage: ['en', 'ar'],
      potentialAction: {
        '@type': 'SearchAction',
        target: origin + '/devices.html',
        'query-input': 'required name=search_term_string',
      },
    },
    {
      '@context': 'https://schema.org',
      '@type': 'Person',
      '@id': origin + '/#person',
      name: cfg.creator,
      alternateName: cfg.alternateNames,
      url: cfg.creatorUrl,
      email: cfg.email,
      telephone: cfg.phone,
      jobTitle: cfg.jobTitle,
      worksFor: {
        '@type': 'Organization',
        name: 'CARE-PRO',
        address: { '@type': 'PostalAddress', addressLocality: 'Jeddah', addressCountry: 'SA' },
      },
      homeLocation: { '@type': 'Place', name: cfg.location },
      sameAs: [
        cfg.linkedIn,
        cfg.instagram,
        cfg.portfolioUrl,
        cfg.parentBrandUrl,
        'https://cv.linux-aios.com',
        'https://faizanai.linux-aios.com',
        'https://aitrade.linux-aios.com',
        'https://helpdesk.linux-aios.com',
        'https://timesheet.linux-aios.com',
        'https://transportation.care-pro.linux-aios.com',
      ],
      knowsAbout: [
        'Workforce Management',
        'Project Management',
        'Operations Coordination',
        'HR Operations',
        'Transportation Logistics',
        'AI for Business',
        'Linux AIOS',
        'Network Monitoring',
        'WiFi LAN scanning',
      ],
    },
    {
      '@context': 'https://schema.org',
      '@type': 'SoftwareApplication',
      name: cfg.siteName,
      applicationCategory: 'BusinessApplication',
      operatingSystem: 'Windows, macOS, Linux',
      url: origin + '/',
      author: { '@id': origin + '/#person' },
      offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
      description:
        'Free local network monitor: scan Wi‑Fi and LAN devices, network map, DNS log merge. By Mohammad Faizan Khan.',
    },
    {
      '@context': 'https://schema.org',
      '@type': 'WebPage',
      '@id': canonical + '#webpage',
      url: canonical,
      name: title,
      description: description,
      isPartOf: { '@id': origin + '/#website' },
      about: { '@id': origin + '/#person' },
      inLanguage: 'en',
    },
    {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Linux AIOS', item: cfg.parentBrandUrl },
        { '@type': 'ListItem', position: 2, name: cfg.creator, item: cfg.creatorUrl },
        { '@type': 'ListItem', position: 3, name: cfg.siteName, item: origin + '/' },
        { '@type': 'ListItem', position: 4, name: page.title.split('—')[0].trim(), item: canonical },
      ],
    },
  ];

  if (pageKey === 'about' && cfg.officialSites) {
    graph.push({
      '@context': 'https://schema.org',
      '@type': 'ItemList',
      name: 'Mohammad Faizan Khan — Official websites',
      itemListElement: cfg.officialSites.map((s, i) => ({
        '@type': 'ListItem',
        position: i + 1,
        name: s.name,
        url: s.url,
      })),
    });
  }

  const script = document.createElement('script');
  script.type = 'application/ld+json';
  script.id = 'seo-jsonld';
  script.textContent = JSON.stringify(graph);
  document.head.appendChild(script);
})();
