/** Logo + creator — green phosphor filter (green theme) or grayscale (B&W theme). */
(function (global) {
  const LOGO_GREEN = '/assets/logo.png';
  const LOGO_MONO = '/assets/logo-mono.png';
  const CREATOR_GREEN = '/assets/creator.png';
  const CREATOR_MONO = '/assets/creator-mono.png';

  const GREEN_FILTER =
    'brightness(0) saturate(100%) invert(58%) sepia(99%) saturate(2800%) hue-rotate(86deg) brightness(1.14) contrast(1.06)';
  const MONO_FILTER = 'grayscale(1) contrast(1.15) brightness(1.06)';

  function styleImg(img) {
    img.style.backgroundColor = 'transparent';
    img.style.border = 'none';
    img.style.outline = 'none';
    img.style.boxShadow = 'none';
  }

  function applyFilter(img, mono) {
    const f = mono ? MONO_FILTER : GREEN_FILTER;
    img.style.filter = f;
    img.style.webkitFilter = f;
  }

  function setThemedImage(img, primaryUrl, fallbackUrl, mono, kind) {
    styleImg(img);
    img.classList.toggle('asset-mono', mono);
    img.classList.toggle('asset-green', !mono);
    img.dataset.retroKind = kind;

    const loadPrimary = () => {
      img.dataset.retroAsset = primaryUrl;
      img.dataset.retroFallback = '';
      applyFilter(img, mono);
      img.src = `${primaryUrl}?theme=${mono ? 'mono' : 'green'}&_${Date.now()}`;
    };

    img.onload = () => applyFilter(img, mono);

    img.onerror = () => {
      img.onerror = null;
      if (img.dataset.retroFallback === '1') return;
      img.dataset.retroFallback = '1';
      img.dataset.retroAsset = fallbackUrl;
      applyFilter(img, mono);
      img.src = `${fallbackUrl}?fallback=1&_${Date.now()}`;
    };

    loadPrimary();
  }

  function applyImages(mono) {
    const logoPrimary = mono ? LOGO_MONO : LOGO_GREEN;
    const logoFallback = mono ? LOGO_GREEN : LOGO_MONO;
    const photoPrimary = mono ? CREATOR_MONO : CREATOR_GREEN;
    const photoFallback = mono ? CREATOR_GREEN : CREATOR_MONO;

    document.querySelectorAll('.coin-flip-logo, .logo-img').forEach((img) => {
      setThemedImage(img, logoPrimary, logoFallback, mono, 'logo');
    });
    document.querySelectorAll('.coin-flip-photo').forEach((img) => {
      setThemedImage(img, photoPrimary, photoFallback, mono, 'photo');
    });
  }

  function init() {
    document.querySelectorAll('.logo-img').forEach((img) => {
      if (img.closest('.coin-flip')) return;
      img.classList.add('logo-ready');
      img.classList.remove('logo-on-black', 'fallback-invert', 'processed');
      styleImg(img);
    });
    if (document.body?.classList.contains('retro-terminal')) {
      applyImages(document.body.classList.contains('retro-mono'));
    }
  }

  global.RetroAssets = { applyImages, GREEN_FILTER, MONO_FILTER };

  global.addEventListener('retro-theme-change', (e) => {
    applyImages(Boolean(e.detail?.mono));
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})(window);
