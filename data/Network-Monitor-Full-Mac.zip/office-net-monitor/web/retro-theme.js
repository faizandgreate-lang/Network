/** CRT theme: random on first visit; button + session stick; logo/photo match theme. */
(function (global) {
  const STORAGE_KEY = 'retroTheme';
  const GREEN = '#33ff66';
  const MONO_ACCENT = '#ffffff';
  const MONO_OFFLINE = '#888888';
  const GREEN_OFFLINE = '#ff5555';

  function isMono() {
    return document.body?.classList.contains('retro-mono');
  }

  function accent() {
    return isMono() ? MONO_ACCENT : GREEN;
  }

  function offlineStroke() {
    return isMono() ? MONO_OFFLINE : GREEN_OFFLINE;
  }

  function pickRandomMono() {
    return Math.random() < 0.5;
  }

  function readSavedMono() {
    try {
      const v = sessionStorage.getItem(STORAGE_KEY);
      if (v === 'mono') return true;
      if (v === 'green') return false;
    } catch (_) {
      /* ignore */
    }
    return null;
  }

  function saveTheme(mono) {
    try {
      sessionStorage.setItem(STORAGE_KEY, mono ? 'mono' : 'green');
    } catch (_) {
      /* ignore */
    }
  }

  function updateThemeButton(mono) {
    const btn = document.getElementById('theme-toggle');
    if (!btn) return;
    const label = btn.querySelector('.theme-toggle-label');
    const text =
      typeof window.t === 'function'
        ? window.t(mono ? 'theme.bw' : 'theme.green')
        : mono
          ? 'THEME: B&W'
          : 'THEME: GREEN';
    if (label) label.textContent = text;
    else btn.textContent = text;
    btn.dataset.theme = mono ? 'mono' : 'green';
    btn.setAttribute(
      'aria-label',
      mono ? 'Switch to green and black theme' : 'Switch to black and white theme',
    );
  }

  function apply(mono, persist) {
    if (!document.body) return;
    document.body.classList.toggle('retro-mono', mono);
    document.documentElement.dataset.retroTheme = mono ? 'mono' : 'green';
    if (persist) saveTheme(mono);
    updateThemeButton(mono);
    if (global.RetroAssets?.applyImages) {
      global.RetroAssets.applyImages(mono);
    }
    global.dispatchEvent(
      new CustomEvent('retro-theme-change', { detail: { mono, accent: accent() } }),
    );
  }

  function toggleTheme() {
    apply(!isMono(), true);
  }

  function initTheme() {
    if (!document.body?.classList.contains('retro-terminal')) return;
    const saved = readSavedMono();
    const mono = saved === null ? pickRandomMono() : saved;
    apply(mono, false);
    const btn = document.getElementById('theme-toggle');
    if (btn && !btn.dataset.wired) {
      btn.dataset.wired = '1';
      btn.addEventListener('click', toggleTheme);
    }
  }

  global.RetroTheme = {
    accent,
    offlineStroke,
    isMono,
    apply,
    toggleTheme,
    pickRandomMono,
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTheme);
  } else {
    initTheme();
  }

  global.addEventListener('locale-change', () => {
    updateThemeButton(global.RetroTheme?.isMono?.() ?? false);
  });
})(window);
