logo.png / logo-mono.png — MFK monogram (green or white, transparent BG; rebuilt on start)
creator.png / creator-mono.png — Creator portrait (green or white, transparent BG; rebuilt on start)

The app also loads these from Cursor assets if missing here.
