"""Copy logo + creator photo into web/assets on startup."""
from __future__ import annotations

import shutil
from pathlib import Path

WEB = Path(__file__).resolve().parent.parent / "web"
ASSETS = WEB / "assets"

LOGO_NAME = "logo.png"
LOGO_MONO_NAME = "logo-mono.png"
CREATOR_NAME = "creator.png"
CREATOR_MONO_NAME = "creator-mono.png"

LOGO_SOURCES = (
    "Sighnature-89f1f5d7-258f-44ce-ba5a-f4bd7de00c50.png",
    "signature.png",
    "logo.png",
)

CREATOR_SOURCES = (
    "MOHAMMAD_FAIZAN_KHAN-8c6c138d-b559-4c21-b010-13d213909dd4.png",
    "creator.png",
)

# Terminal phosphor green — matches web --ok (#33ff66)
_PHOSPHOR = (51, 255, 102)


def _phosphor_rgb(intensity: float) -> tuple[int, int, int]:
    t = max(0.0, min(1.0, intensity))
    return (
        int(_PHOSPHOR[0] * t),
        int(_PHOSPHOR[1] * t),
        int(_PHOSPHOR[2] * t),
    )


def _mono_rgb(intensity: float) -> tuple[int, int, int]:
    v = int(255 * max(0.0, min(1.0, intensity)))
    return (v, v, v)


def _search_dirs() -> list[Path]:
    root = WEB.parent
    home = Path.home()
    return [
        ASSETS,
        root / "assets",
        root.parent / "assets",
        home
        / ".cursor"
        / "projects"
        / "Users-mohammadkhan-Downloads-RuView-main"
        / "assets",
        home / "Downloads" / "RuView-main" / "assets",
        home / "Downloads" / "RuView-main" / "office-net-monitor" / "assets",
    ]


def _find_file(names: tuple[str, ...]) -> Path | None:
    for folder in _search_dirs():
        if not folder.is_dir():
            continue
        for name in names:
            p = folder / name
            if p.is_file():
                return p
    return None


def _logo_transparent(src: Path, dest: Path, *, phosphor: bool = True) -> bool:
    """Logo ink on transparent PNG — phosphor green or white (mono)."""
    try:
        from PIL import Image
    except ImportError:
        return False

    im = Image.open(src).convert("RGBA")
    pad = 12
    w, h = im.size
    out = Image.new("RGBA", (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
    px = im.load()
    op = out.load()
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            lum = (r + g + b) / 3.0
            if lum >= 150 or (a < 40 and lum > 120):
                continue
            strength = (1.0 - min(lum, 150) / 150.0) * (a / 255.0)
            if strength > 0.03:
                rgb = _phosphor_rgb(strength) if phosphor else _mono_rgb(strength)
                alpha = int(255 * min(1.0, strength))
                op[x + pad, y + pad] = (*rgb, alpha)
    dest.parent.mkdir(parents=True, exist_ok=True)
    out.save(dest, "PNG")
    return True


def _creator_transparent(src: Path, dest: Path, *, phosphor: bool = True) -> bool:
    """Portrait on transparent PNG — phosphor green or white/gray (mono)."""
    try:
        from PIL import Image, ImageEnhance
    except ImportError:
        return False

    im = Image.open(src).convert("RGBA")
    im = ImageEnhance.Contrast(im).enhance(1.35)
    w, h = im.size
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    px = im.load()
    op = out.load()
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if a < 20:
                continue
            lum = 0.299 * r + 0.587 * g + 0.114 * b
            if lum >= 210 and max(r, g, b) - min(r, g, b) < 45:
                continue
            if lum >= 248:
                continue
            t = min(1.0, (lum / 255.0) * 0.94)
            if t < 0.04:
                continue
            rgb = _phosphor_rgb(t) if phosphor else _mono_rgb(t)
            alpha = int(255 * min(1.0, t * (a / 255.0)))
            if alpha < 10:
                continue
            op[x, y] = (*rgb, alpha)
    dest.parent.mkdir(parents=True, exist_ok=True)
    out.save(dest, "PNG")
    return True


def install_web_assets() -> dict[str, str]:
    """Rebuild theme assets from original sources (never from already-tinted PNGs)."""
    ASSETS.mkdir(parents=True, exist_ok=True)
    logo = ASSETS / LOGO_NAME
    logo_mono = ASSETS / LOGO_MONO_NAME
    creator = ASSETS / CREATOR_NAME
    creator_mono = ASSETS / CREATOR_MONO_NAME

    logo_src = _find_file(LOGO_SOURCES)
    if logo_src:
        if not _logo_transparent(logo_src, logo, phosphor=True):
            shutil.copy2(logo_src, logo)
        if not _logo_transparent(logo_src, logo_mono, phosphor=False):
            shutil.copy2(logo_src, logo_mono)

    creator_src = _find_file(CREATOR_SOURCES)
    if creator_src:
        if not _creator_transparent(creator_src, creator, phosphor=True):
            shutil.copy2(creator_src, creator)
        if not _creator_transparent(creator_src, creator_mono, phosphor=False):
            shutil.copy2(creator_src, creator_mono)

    return {
        "logo": str(logo) if logo.is_file() else "missing",
        "logo_mono": str(logo_mono) if logo_mono.is_file() else "missing",
        "creator": str(creator) if creator.is_file() else "missing",
        "creator_mono": str(creator_mono) if creator_mono.is_file() else "missing",
    }
